let timerInterval;

chrome.runtime.onMessage.addListener((message) => {
  if (message.action === "startTimer") {
    const timer = message.timer;

    // Save the timer value to local storage for persistence
    chrome.storage.local.set({ timer });

    clearInterval(timerInterval);
    startCountdown(timer);
  } else if (message.action === "stopTimer") {
    clearInterval(timerInterval); // Stop the timer
    chrome.storage.local.remove("timer"); // Clear the saved timer
  }
});

function startCountdown(timerInSeconds) {
  const updateCountdown = () => {
    // Calculate hours, minutes, and seconds
    const hours = String(Math.floor(timerInSeconds / 3600)).padStart(2, "0");
    const minutes = String(Math.floor((timerInSeconds % 3600) / 60)).padStart(2, "0");
    const seconds = String(timerInSeconds % 60).padStart(2, "0");

    // Send updated countdown values to popup
    chrome.runtime.sendMessage({
      action: "updateCountdown",
      countdown: { hours, minutes, seconds },
    });

    if (timerInSeconds <= 0) {
      clearInterval(timerInterval); // Stop the timer when it reaches 0

      // Reload the active tab
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]?.id) {
          chrome.tabs.reload(tabs[0].id, () => {
            // Restart the countdown after reload using the saved timer value
            chrome.storage.local.get("timer", (data) => {
              if (data.timer) {
                startCountdown(data.timer);
              }
            });
          });
        }
      });
    } else {
      timerInSeconds--; // Decrement the timer
    }
  };

  // Initialize the countdown
  updateCountdown();
  timerInterval = setInterval(updateCountdown, 1000); // Update every second
}
