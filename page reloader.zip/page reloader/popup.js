document.getElementById("timerForm").addEventListener("submit", (e) => {
  e.preventDefault();

  const hours = parseInt(document.getElementById("hours").value) || 0;
  const minutes = parseInt(document.getElementById("minutes").value) || 0;
  const seconds = parseInt(document.getElementById("seconds").value) || 0;

  const timerInSeconds = hours * 3600 + minutes * 60 + seconds;

  if (timerInSeconds > 0) {
    chrome.storage.local.set({ timer: timerInSeconds });
    chrome.runtime.sendMessage({ action: "startTimer", timer: timerInSeconds });
  }
});

document.getElementById("stopButton").addEventListener("click", () => {
  chrome.runtime.sendMessage({ action: "stopTimer" });
  document.getElementById("countdown").textContent = "Countdown: --:--:--";
});

chrome.runtime.onMessage.addListener((message) => {
  if (message.action === "updateCountdown") {
    const { hours, minutes, seconds } = message.countdown;
    document.getElementById("countdown").textContent = `Countdown: ${hours}:${minutes}:${seconds}`;
  }
});
